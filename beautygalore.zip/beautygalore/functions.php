<?php
/**
 * Beauty Galore Kenya child theme. Built like our RealBeef and The Daily themes: jewellery and piercing prices are
 * WooCommerce products (edited in wp-admin) rendered on a one-page site. There is no WooCommerce checkout: the bag
 * and the piercing booking run in the browser (assets/bg.js) and send a formatted message to the studio on WhatsApp,
 * so the static Vercel copy works the same. Sources for every fact are in the project README.
 */

const BG_PHONE      = '0717 995 803';
const BG_PHONE_INTL = '+254 717 995 803';
const BG_TEL        = '+254717995803';
const BG_WA         = '254717995803';
const BG_IG         = 'https://www.instagram.com/beautygaloreglobal/';
const BG_IG_HANDLE  = '@beautygaloreglobal';
const BG_FOLLOWERS  = '8,000+'; // 8,039 on 18 Nov 2026.
const BG_ADDRESS    = 'Westlands Commercial Center, Nairobi';
const BG_PREVIEW    = true;     // Shows "sample" notes and keeps the site out of search until Beauty Galore confirms.
const BG_FONTS      = 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Jost:wght@300;400;500;600&family=Pinyon+Script&display=swap';

/** Opening hours from their Instagram bio, by weekday (0 = Sunday): [open hour, close hour]. */
const BG_HOURS = [ 0 => null, 1 => [ 9, 18 ], 2 => [ 9, 18 ], 3 => [ 9, 18 ], 4 => [ 9, 18 ], 5 => [ 9, 18 ], 6 => [ 10, 17 ] ];

/** Delivery options (fees are samples until Beauty Galore confirms). */
const BG_DELIVERY = [
	'pickup'  => [ 'label' => 'Pick up in Westlands', 'detail' => 'Westlands Commercial Center, ready same day', 'fee' => 0 ],
	'rider'   => [ 'label' => 'Nairobi rider delivery', 'detail' => 'Same day when ordered before 3pm', 'fee' => 300 ],
	'courier' => [ 'label' => 'Countrywide courier', 'detail' => '1–2 days to any town in Kenya', 'fee' => 400 ],
];

/** From their price list post. */
const BG_STUDIO_NOTES = [
	'We pierce with a sterile needle, never a gun.',
	'Prices include stainless steel piercing jewellery.',
	'Upgrade to titanium at an extra cost, with 50% off titanium jewellery alongside your piercing.',
	'Jewellery change is free when you spend over KSh 1,500.',
];

/** Placeholders until Beauty Galore shares quotes from its Reviews highlight (with permission). */
const BG_REVIEWS = [
	[ 'So gentle! I was nervous about my helix but it was over before I knew it. She explained the aftercare clearly.', 'Achieng O.', 'Helix piercing · Kilimani' ],
	[ "I've showered and gone to the gym in my rings for months and they still look brand new. No green fingers at all.", 'Mercy W.', 'Stainless rings · Westlands' ],
	[ 'They mapped out my whole ear stack and the studs they suggested are exactly what I wanted. So welcoming.', 'Faith N.', 'Ear stack · Ruaka' ],
	[ 'Ordered an anniversary box on WhatsApp in the afternoon and it came the same evening, wrapped with a note.', 'Brian K.', 'Gift box · Lavington' ],
	[ 'Clean, calm and professional. Needle, not a gun, and I was in and out on my lunch break.', 'Joy M.', 'Nose piercing · Parklands' ],
];

/** Recent posts saved from their public profile. */
const BG_IG_POSTS = [
	[ 'p07.jpg', 'https://www.instagram.com/beautygaloreglobal/reel/Df1dwZToP46/', 'Gold swirl ring' ],
	[ 'p03.jpg', 'https://www.instagram.com/beautygaloreglobal/p/DUn1el9CB7y/', 'Piercing price list' ],
	[ 'p06.jpg', 'https://www.instagram.com/beautygaloreglobal/p/Df1eA3foX5s/', 'Layered necklaces' ],
	[ 'p08.jpg', 'https://www.instagram.com/beautygaloreglobal/p/DfzkUnTockb/', 'Black November necklace deal' ],
	[ 'p05.jpg', 'https://www.instagram.com/beautygaloreglobal/reel/Df3tHYtoO1a/', 'Crystal studs' ],
	[ 'p11.jpg', 'https://www.instagram.com/beautygaloreglobal/p/DfrVkxbCIeN/', 'Square sunglasses' ],
];

function bg_faq() {
	$fees = [];
	foreach ( BG_DELIVERY as $d ) if ( $d['fee'] ) $fees[] = $d['label'] . ': ' . bg_ksh( $d['fee'] );
	return [
		[ 'How do I find you at Westlands Commercial Center?', "We're inside Westlands Commercial Center, Nairobi. Use the map below, or WhatsApp " . BG_PHONE . " and we'll send a pin and walk you in. Driving? Ask us about parking when you book." ],
		[ 'How should I prepare for my piercing appointment?', 'Eat a proper meal and drink water beforehand, and avoid alcohol for 24 hours. Bring a valid ID; clients under 18 come with a parent or guardian. Tie long hair back for ear piercings.' ],
		[ 'Do I need a deposit? Can I reschedule?', "Your slot is held once we confirm on WhatsApp. To move it, message us at least 24 hours before so we can offer the time to someone else. Some sessions may need a small M-Pesa deposit, which we'll mention when confirming." ],
		[ 'Will my stainless jewellery tarnish?', "Our stainless pieces are made to be worn daily and in water without turning or fading. Store them dry, away from perfume, and wipe with a soft cloth. If a piece develops a fault from normal wear, bring it in and we'll make it right." ],
		[ 'Do you deliver? How much does it cost?', 'Yes. ' . implode( ' · ', $fees ) . '. Pick-up from the studio is free. Riders deliver the same day for orders confirmed before 3pm.' ],
		[ 'How do I pay?', 'M-Pesa, card or cash, in studio or once we confirm your WhatsApp order. We send payment details with your confirmation.' ],
	];
}

function bg_ksh( $n ) {
	return 'KSh ' . number_format( (float) $n );
}
function bg_wa( $text ) {
	return 'https://wa.me/' . BG_WA . '?text=' . rawurlencode( $text );
}
function bg_asset( $name ) {
	return get_stylesheet_directory_uri() . '/assets/' . $name;
}

/** Script wordmark echoing their hand-lettered logo, with a blossom sprig. */
function bg_blossom( $size = 30 ) {
	$petals = '';
	foreach ( [ 0, 72, 144, 216, 288 ] as $r ) $petals .= '<ellipse cx="20" cy="9" rx="3.2" ry="5" transform="rotate(' . $r . ' 20 13)"/>';
	return '<svg class="bg-blossom" viewBox="0 0 32 32" width="' . $size . '" height="' . $size . '" aria-hidden="true"><path d="M4 28c6-4 10-10 12-18M11 19c-3-1-5 0-6 2" stroke="#9c7a36" stroke-width="1.2" fill="none" stroke-linecap="round"/><g fill="#f4c2c2" stroke="#d85a7f" stroke-width=".8">' . $petals . '</g><circle cx="20" cy="13" r="1.8" fill="#c5a059"/><circle cx="8" cy="22" r="2.2" fill="#fadadd" stroke="#d85a7f" stroke-width=".6"/></svg>';
}
function bg_logo( $light = false ) {
	return '<a href="/" class="bg-logo' . ( $light ? ' bg-logo--light' : '' ) . '" aria-label="Beauty Galore Kenya home">' . bg_blossom() . '<span><strong>Beauty Galore</strong><em>Kenya</em></span></a>';
}

/** Line drawings for products without a photo yet. */
function bg_art( $art, $tone ) {
	$tones = [ 'gold' => [ '#f1dca8', '#c5a059', '#8f6c2c' ], 'silver' => [ '#f4f4f6', '#bfc3cb', '#7d828c' ], 'rose' => [ '#f9d6d9', '#d98f9e', '#a4566a' ] ];
	[ $a, $b, $c ] = $tones[ $tone ] ?? $tones['gold'];
	$id   = 'g-' . $art . '-' . $tone;
	$s    = 'stroke="url(#' . $id . ')" fill="none" stroke-linecap="round" stroke-linejoin="round"';
	$dot  = fn( $x, $y, $r, $fill = '#fff' ) => sprintf( '<circle cx="%s" cy="%s" r="%s" fill="%s" stroke="%s" stroke-width="1.2"/>', $x, $y, $r, $fill, $c );
	switch ( $art ) {
		case 'band':
			$g = "<g $s stroke-width=\"6\"><ellipse cx=\"60\" cy=\"52\" rx=\"30\" ry=\"12\"/><ellipse cx=\"60\" cy=\"66\" rx=\"30\" ry=\"12\"/><ellipse cx=\"60\" cy=\"80\" rx=\"30\" ry=\"12\"/></g>";
			break;
		case 'signet':
			$g = "<g $s><path d=\"M34 66a26 26 0 1 0 52 0\" stroke-width=\"8\"/><ellipse cx=\"60\" cy=\"48\" rx=\"20\" ry=\"14\" stroke-width=\"6\" fill=\"$a\"/></g>";
			break;
		case 'hoop':
			$g = "<g $s stroke-width=\"9\"><circle cx=\"44\" cy=\"62\" r=\"20\"/><circle cx=\"80\" cy=\"62\" r=\"20\"/></g>";
			break;
		case 'cuff':
			$g = "<g $s><path d=\"M40 30c28-10 50 10 46 40s-30 34-44 26\" stroke-width=\"7\"/><path d=\"M48 42c18-6 30 6 28 24\" stroke-width=\"3\"/></g>" . $dot( 42, 96, 4, $b );
			break;
		case 'stud':
			$g = "<g $s stroke-width=\"4\">";
			foreach ( [ [ 38, 50 ], [ 78, 44 ], [ 60, 82 ] ] as [ $x, $y ] ) $g .= "<circle cx=\"$x\" cy=\"$y\" r=\"10\" fill=\"#fff\"/>";
			$g .= '</g>';
			break;
		case 'chain':
			$g = "<g $s><path d=\"M20 24c4 40 20 62 40 62s36-22 40-62\" stroke-width=\"3\" stroke-dasharray=\"7 4\"/><rect x=\"53\" y=\"84\" width=\"14\" height=\"18\" rx=\"7\" stroke-width=\"4\"/></g>";
			break;
		case 'bracelet':
			$g = "<g $s><ellipse cx=\"60\" cy=\"62\" rx=\"40\" ry=\"22\" stroke-width=\"5\"/></g>";
			for ( $i = 0; $i < 12; $i++ ) $g .= $dot( round( 60 + 40 * cos( $i / 12 * M_PI * 2 ), 1 ), round( 62 + 22 * sin( $i / 12 * M_PI * 2 ), 1 ), 3.6 );
			break;
		case 'labret':
			$g = "<g $s stroke-width=\"5\"><path d=\"M60 46v44\"/><circle cx=\"60\" cy=\"40\" r=\"11\" fill=\"#fff\"/><ellipse cx=\"60\" cy=\"94\" rx=\"14\" ry=\"4\"/></g>";
			break;
		case 'septum':
			$g = "<g $s><path d=\"M34 50a26 26 0 0 0 52 0\" stroke-width=\"7\"/></g>" . $dot( 60, 78, 5, $b ) . $dot( 49, 74, 3.5, $b ) . $dot( 71, 74, 3.5, $b );
			break;
		case 'gift':
			$g = "<g $s stroke-width=\"5\"><rect x=\"26\" y=\"50\" width=\"68\" height=\"48\" rx=\"4\"/><rect x=\"22\" y=\"38\" width=\"76\" height=\"14\" rx=\"3\"/><path d=\"M60 38v60\"/><path d=\"M60 38c-8-14-26-14-22-2s22 2 22 2zM60 38c8-14 26-14 22-2s-22 2-22 2z\" stroke-width=\"4\"/></g>";
			break;
		default: // ring
			$g = "<g $s><circle cx=\"60\" cy=\"68\" r=\"30\" stroke-width=\"8\"/></g>";
			for ( $i = 0; $i < 5; $i++ ) $g .= $dot( 42 + $i * 9, 41 + abs( $i - 2 ) * 2.5, 3 );
	}
	return "<span class=\"bg-art bg-art--$tone\"><svg viewBox=\"0 0 120 120\" aria-hidden=\"true\"><defs><linearGradient id=\"$id\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0\" stop-color=\"$a\"/><stop offset=\".55\" stop-color=\"$b\"/><stop offset=\"1\" stop-color=\"$c\"/></linearGradient></defs>$g</svg></span>";
}

/** Shop categories in tab order (without the booking-only services category). */
function bg_categories() {
	$out = [];
	foreach ( get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => false, 'exclude' => [ get_option( 'default_product_cat' ) ] ] ) as $t ) {
		if ( $t->slug === 'services' ) continue;
		$out[ $t->slug ] = [ 'name' => $t->name, 'blurb' => $t->description, 'order' => (int) get_term_meta( $t->term_id, 'order', true ) ];
	}
	uasort( $out, fn( $a, $b ) => $a['order'] <=> $b['order'] );
	return $out;
}

/** Jewellery and piercing services in menu order. */
function bg_all_products() {
	static $out = null;
	if ( $out !== null ) return $out;
	$out = [ 'shop' => [], 'piercings' => [] ];
	foreach ( wc_get_products( [ 'status' => 'publish', 'limit' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ] ) as $p ) {
		$cats = wp_get_post_terms( $p->get_id(), 'product_cat', [ 'fields' => 'slugs' ] );
		$cat  = $cats[0] ?? '';
		$base = [ 'id' => $p->get_slug(), 'name' => $p->get_name(), 'price' => (int) $p->get_regular_price() ];
		if ( $cat === 'services' ) {
			$out['piercings'][] = $base + [
				'group' => (string) $p->get_meta( '_bg_group' ) ?: 'Other',
				'heal'  => (string) $p->get_meta( '_bg_heal' ),
				'adult' => $p->get_meta( '_bg_adult' ) === 'yes',
			];
			continue;
		}
		$out['shop'][] = $base + [
			'cat'    => $cat,
			'desc'   => wp_strip_all_tags( $p->get_short_description() ),
			'img'    => (string) get_the_post_thumbnail_url( $p->get_id(), 'full' ),
			'art'    => (string) $p->get_meta( '_bg_art' ) ?: 'ring',
			'tone'   => (string) $p->get_meta( '_bg_tone' ) ?: 'gold',
			'badge'  => (string) $p->get_meta( '_bg_badge' ),
			'sample' => $p->get_meta( '_bg_sample' ) === 'yes',
		];
	}
	return $out;
}

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	wp_enqueue_style( 'bg-fonts', BG_FONTS, [], null );
	wp_enqueue_style( 'bg', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'bg', bg_asset( 'bg.js' ), [], filemtime( $dir . '/assets/bg.js' ), true );
	$all  = bg_all_products();
	$shop = [];
	foreach ( $all['shop'] as $p ) $shop[ $p['id'] ] = [ 'name' => $p['name'], 'price' => $p['price'], 'img' => $p['img'], 'art' => bg_art( $p['art'], $p['tone'] ) ];
	wp_add_inline_script( 'bg', 'window.BG=' . wp_json_encode( [
		'wa'        => BG_WA,
		'phone'     => BG_PHONE,
		'address'   => BG_ADDRESS,
		'hours'     => BG_HOURS,
		'delivery'  => BG_DELIVERY,
		'products'  => $shop,
		'piercings' => $all['piercings'],
	] ) . ';', 'before' );
	// WooCommerce's own shop styles and scripts aren't used: the shop and bag are the theme's.
	foreach ( [ 'woocommerce-general', 'woocommerce-layout', 'woocommerce-smallscreen', 'wc-blocks-style' ] as $h ) wp_dequeue_style( $h );
}, 20 );
add_action( 'wp_enqueue_scripts', function () {
	foreach ( [ 'woocommerce', 'wc-add-to-cart', 'wc-cart-fragments', 'jquery-blockui', 'wc-jquery-blockui', 'js-cookie', 'wc-js-cookie', 'sourcebuster-js', 'wc-order-attribution' ] as $h ) {
		wp_dequeue_script( $h );
	}
}, 100 );
add_filter( 'wc_order_attribution_allow_tracking', '__return_false' );
add_filter( 'pre_option_woocommerce_feature_order_attribution_enabled', fn() => 'no' );
add_action( 'enqueue_block_editor_assets', fn() => wp_enqueue_style( 'bg-fonts', BG_FONTS, [], null ) );
add_action( 'after_setup_theme', fn() => add_editor_style( 'style.css' ) );

const BG_TITLE = 'Beauty Galore Kenya | Jewellery, Ear Piercings & Gifts in Westlands, Nairobi';
const BG_DESC  = 'The best jewellery to suit your style. Tarnish-free stainless jewellery, needle piercings by appointment and curated gifts at Westlands Commercial Center, Nairobi. Order or book on WhatsApp 0717 995 803.';
add_filter( 'pre_get_document_title', fn( $t ) => is_front_page() ? BG_TITLE : $t );
add_action( 'wp_head', function () {
	if ( ! is_front_page() ) return;
	printf(
		'<meta name="description" content="%1$s"><meta property="og:type" content="website"><meta property="og:locale" content="en_KE"><meta property="og:title" content="%2$s"><meta property="og:description" content="%3$s"><meta property="og:image" content="%4$s">' . "\n",
		esc_attr( BG_DESC ),
		esc_attr( 'Beauty Galore Kenya' ),
		esc_attr( 'Tarnish-free jewellery, precision piercings and curated gifts in Westlands, Nairobi.' ),
		esc_url( bg_asset( 'ig/p07.jpg' ) )
	);
}, 2 );
add_action( 'wp_head', function () {
	echo "<script>document.documentElement.classList.add('bg-js')</script>\n";	echo '<link rel="icon" href="' . esc_url( bg_asset( 'icon.svg' ) ) . '" type="image/svg+xml">' . "\n";
	echo '<meta name="theme-color" content="#FADADD">' . "\n";
}, 1 );

add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );
add_filter( 'pre_option_woocommerce_coming_soon', fn() => 'no' );
add_filter( 'woocommerce_coming_soon_exclude', '__return_true' );

// No WooCommerce checkout: orders and bookings go to WhatsApp from the theme.
add_filter( 'woocommerce_is_purchasable', '__return_false' );
// The shop page, a category or a product page open the one-page site instead.
add_action( 'template_redirect', function () {
	if ( is_shop() || is_product_category() ) {
		$slug = is_product_category() ? get_queried_object()->slug : '';
		wp_safe_redirect( home_url( $slug === 'services' ? '/#book' : '/' . ( $slug ? '?cat=' . $slug : '' ) . '#shop' ), 301 );
		exit;
	}
	if ( is_product() ) {
		$slug = get_post_field( 'post_name', get_queried_object_id() );
		wp_safe_redirect( home_url( str_starts_with( $slug, 'piercing-' ) ? '/#book' : '/#p-' . $slug ), 301 );
		exit;
	}
} );

/* Shop ------------------------------------------------------------------------------------------------------------ */

function bg_card( $p, $cats ) {
	$media = $p['img']
		? sprintf( '<img src="%1$s" alt="%2$s" loading="lazy" width="640" height="800">', esc_url( $p['img'] ), esc_attr( $p['name'] ) )
		: bg_art( $p['art'], $p['tone'] );
	$badge = $p['badge'] ? '<span class="bg-badge">' . esc_html( $p['badge'] ) . '</span>' : '';
	$msg   = "Hi Beauty Galore! I'd like to order:\n• {$p['name']} (" . bg_ksh( $p['price'] ) . ")\n\nIs it available?";
	return sprintf(
		'<li class="bg-card" id="p-%1$s" data-cat="%2$s">'
		. '<div class="bg-card__media">%3$s%4$s<button type="button" class="bg-card__quick" data-bg-add="%1$s">+ Add to Bag</button></div>'
		. '<p class="bg-card__cat">%5$s</p><h3>%6$s</h3><p class="bg-card__desc">%7$s</p><p class="bg-card__price">%8$s</p>'
		. '<div class="bg-card__actions"><button type="button" class="bg-btn-solid" data-bg-add="%1$s">Add to bag</button>'
		. '<a class="bg-card__wa" href="%9$s" target="_blank" rel="noopener" aria-label="Order %6$s via WhatsApp">%10$s Order on WhatsApp</a></div></li>',
		esc_attr( $p['id'] ),
		esc_attr( $p['cat'] ),
		$media,
		$badge,
		esc_html( $cats[ $p['cat'] ]['name'] ?? '' ),
		esc_html( $p['name'] ),
		esc_html( $p['desc'] ),
		bg_ksh( $p['price'] ),
		esc_url( bg_wa( $msg ) ),
		bg_icon( 'wa', 14 )
	);
}

function bg_icon( $name, $size = 18 ) {
	$paths = [
		'wa'      => '<path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" d="M4 20l1.3-3.9A8 8 0 1 1 8 18.8z"/>',
		'bag'     => '<path fill="none" stroke="currentColor" stroke-width="1.6" d="M5 8h14l-1 12H6zM9 8V6a3 3 0 0 1 6 0v2"/>',
		'check'   => '<path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="m5 12 5 5 9-10"/>',
		'gem'     => '<path fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" d="M6 3h12l4 6-10 12L2 9zM2 9h20M12 21 8 9l4-6 4 6z"/>',
		'shield'  => '<path fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6zM9 12l2 2 4-4"/>',
		'sparkle' => '<path fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z"/>',
		'pin'     => '<path fill="none" stroke="currentColor" stroke-width="1.5" d="M12 21s-7-6.2-7-12a7 7 0 0 1 14 0c0 5.8-7 12-7 12z"/><circle cx="12" cy="9" r="2.5" fill="none" stroke="currentColor" stroke-width="1.5"/>',
		'wand'    => '<path fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" d="M4 20 15 9M14 4v2M19 9h2M18 5l1.5-1.5M10 4.5l1 1.5M19.5 13l-1.5-1"/>',
		'truck'   => '<path fill="none" stroke="currentColor" stroke-width="1.5" d="M3 7h11v9H3zM14 10h4l3 3v3h-7M7 19a2 2 0 1 0 0-.1M17 19a2 2 0 1 0 0-.1"/>',
		'drop'    => '<path fill="none" stroke="currentColor" stroke-width="1.5" d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/>',
		'moon'    => '<path fill="none" stroke="currentColor" stroke-width="1.5" d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
		'ruler'   => '<path fill="none" stroke="currentColor" stroke-width="1.5" d="M3 17 17 3l4 4L7 21zM7 13l2 2M10 10l2 2M13 7l2 2"/>',
		'ig'      => '<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="17.3" cy="6.7" r="1.1" fill="currentColor"/>',
		'phone'   => '<path fill="none" stroke="currentColor" stroke-width="1.6" d="M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2z"/>',
		'clock'   => '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="1.5"/>',
		'id'      => '<rect x="3" y="5" width="18" height="14" rx="2" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="9" cy="11" r="2" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M6 16c1-2 5-2 6 0M14 10h4M14 13h3" stroke="currentColor" stroke-width="1.5"/>',
	];
	return '<svg viewBox="0 0 24 24" width="' . $size . '" height="' . $size . '" aria-hidden="true">' . ( $paths[ $name ] ?? '' ) . '</svg>';
}

add_shortcode( 'bg_shop', function () {
	$cats  = bg_categories();
	$tabs  = '<button type="button" class="is-on" data-bg-cat="all" aria-pressed="true">All</button>';
	$notes = '<p data-bg-cat-note="all">Waterproof, tarnish-free pieces made for everyday wear, plus gifts that arrive ready to give.</p>';
	foreach ( $cats as $slug => $c ) {
		$tabs  .= sprintf( '<button type="button" data-bg-cat="%1$s" aria-pressed="false">%2$s</button>', esc_attr( $slug ), esc_html( $c['name'] ) );
		$notes .= sprintf( '<p data-bg-cat-note="%1$s" hidden>%2$s</p>', esc_attr( $slug ), esc_html( $c['blurb'] ) );
	}
	$cards = '';
	foreach ( bg_all_products()['shop'] as $p ) $cards .= bg_card( $p, $cats );
	$sample = BG_PREVIEW ? '<p class="bg-note">Preview: jewellery prices are samples until Beauty Galore confirms them.</p>' : '';
	return '<div data-bg-shop><div class="bg-tabs" role="group" aria-label="Filter by category">' . $tabs . '</div><div class="bg-shop-notes">' . $notes . '</div><ul class="bg-cards is-capped">' . $cards . '</ul>'
		. '<button type="button" class="bg-btn-outline bg-more" data-bg-more>Show all ' . count( bg_all_products()['shop'] ) . ' pieces</button>' . $sample . '</div>';
} );

/* Booking --------------------------------------------------------------------------------------------------------- */

add_shortcode( 'bg_booking', function () {
	$pier   = bg_all_products()['piercings'];
	$groups = [];
	foreach ( $pier as $p ) $groups[ $p['group'] ][] = $p;
	$tabs = $lists = '';
	$i    = 0;
	foreach ( $groups as $g => $items ) {
		$key   = sanitize_title( $g );
		$tabs .= sprintf( '<button type="button" data-bg-group="%1$s" aria-pressed="%2$s"%3$s>%4$s</button>', $key, $i ? 'false' : 'true', $i ? '' : ' class="is-on"', esc_html( $g ) );
		$li    = '';
		foreach ( $items as $p ) {
			$meta = $p['heal'] ? 'Heals in ' . $p['heal'] : 'Studio service';
			if ( $p['adult'] ) $meta .= ' · 18+';
			$li .= sprintf(
				'<li><button type="button" class="bg-pick" data-bg-pierce="%1$s" aria-pressed="false"><span class="bg-tick">%2$s</span><span class="bg-pick__name"><b>%3$s</b><small>%4$s</small></span><span class="bg-pick__price">%5$s</span></button></li>',
				esc_attr( $p['id'] ),
				bg_icon( 'check', 14 ),
				esc_html( $p['name'] ),
				esc_html( $meta ),
				bg_ksh( $p['price'] )
			);
		}
		$lists .= sprintf( '<ul class="bg-picks" data-bg-group-list="%1$s"%2$s>%3$s</ul>', $key, $i ? ' hidden' : '', $li );
		$i++;
	}
	$notes = '';
	foreach ( BG_STUDIO_NOTES as $n ) $notes .= '<li><span class="bg-dot">' . bg_icon( 'check', 12 ) . '</span>' . esc_html( $n ) . '</li>';

	ob_start();
	?>
<div class="bg-book">
	<div class="bg-book__intro">
		<span class="bg-rule bg-rule--left" aria-hidden="true"></span>
		<p class="bg-label">Piercings on appointment basis</p>
		<h2>Book your <em>piercing</em></h2>
		<p class="bg-lead">Every session is one-on-one in our Westlands studio, with time to plan your placement and no rush. Choose your piercing, pick a slot and confirm on WhatsApp.</p>
		<ul class="bg-checks"><?php echo $notes; ?></ul>
		<p class="bg-idnote"><?php echo bg_icon( 'id', 18 ); ?> Please bring a valid ID. Clients under 18 come with a parent or guardian.</p>
	</div>
	<div class="bg-book__card" data-bg-booking>
		<div data-bg-wizard>
			<ol class="bg-steps" aria-label="Booking steps">
				<li class="is-on"><span></span><em>1. </em>Placement</li>
				<li><span></span><em>2. </em>Jewellery</li>
				<li><span></span><em>3. </em>Date &amp; time</li>
				<li><span></span><em>4. </em>Your details</li>
			</ol>

			<div class="bg-step" data-bg-step="0">
				<h3>Choose your placement</h3>
				<p class="bg-muted">Select one or more. Prices include stainless steel jewellery.</p>
				<div class="bg-chips"><?php echo $tabs; ?></div>
				<?php echo $lists; ?>
			</div>

			<div class="bg-step" data-bg-step="1" hidden>
				<h3>Select your starter jewellery</h3>
				<p class="bg-muted">Starter pieces are sized to allow for swelling; downsize once you&rsquo;ve healed.</p>
				<label class="bg-option"><input type="radio" name="bg-jewel" value="Stainless steel starter" checked><span><b>Stainless steel starter <i>Included</i></b><small>Included in your piercing price. Polished studs or hoops sized for swelling.</small></span></label>
				<label class="bg-option"><input type="radio" name="bg-jewel" value="Implant-grade titanium upgrade"><span><b>Implant-grade titanium upgrade <i>Extra, quoted in studio</i></b><small>Lightest and gentlest for sensitive skin. 50% off titanium jewellery when you pierce with us.</small></span></label>
			</div>

			<div class="bg-step" data-bg-step="2" hidden>
				<h3>Pick a date and time</h3>
				<p class="bg-muted">Mon–Fri 9am–6pm · Sat 10am–5pm · Closed Sundays</p>
				<div class="bg-days" data-bg-days></div>
				<p class="bg-day-label" data-bg-day-label></p>
				<div class="bg-slots" data-bg-slots></div>
			</div>

			<div class="bg-step" data-bg-step="3" hidden>
				<h3>Your details</h3>
				<label class="bg-field"><span>Full name</span><input data-bg-name autocomplete="name" placeholder="e.g. Wanjiru Kamau"></label>
				<label class="bg-field"><span>Phone number</span><input data-bg-phone type="tel" inputmode="tel" autocomplete="tel" placeholder="07XX XXX XXX"><small data-bg-phone-hint hidden>Enter a Kenyan number like 0712 345 678</small></label>
				<fieldset class="bg-field"><legend>Age confirmation</legend>
					<label class="bg-option bg-option--sm"><input type="radio" name="bg-age" value="adult"><span>I&rsquo;m 18 or over and will bring my ID</span></label>
					<label class="bg-option bg-option--sm"><input type="radio" name="bg-age" value="minor"><span>I&rsquo;m under 18 and will come with a parent or guardian</span></label>
					<small data-bg-age-hint hidden>Nipple piercings are for clients 18 and over.</small>
				</fieldset>
				<label class="bg-field"><span>Notes (optional)</span><textarea data-bg-notes rows="2" placeholder="Allergies, placement ideas, a friend coming along…"></textarea></label>
			</div>

			<div class="bg-book__foot">
				<p class="bg-est"><span>Estimated</span> <b data-bg-total>KSh 0</b><small data-bg-chosen></small></p>
				<button type="button" class="bg-btn-outline" data-bg-back hidden>← Back</button>
				<button type="button" class="bg-btn-gold" data-bg-next disabled>Continue →</button>
			</div>
		</div>

		<div class="bg-summary" data-bg-summary hidden>
			<span class="bg-summary__icon"><?php echo bg_icon( 'sparkle', 24 ); ?></span>
			<h3 data-bg-hello>Almost there!</h3>
			<p class="bg-muted">Send this summary on WhatsApp and the studio will confirm your slot.</p>
			<dl data-bg-summary-list></dl>
			<a class="bg-btn-wa bg-btn-block" data-bg-confirm href="#" target="_blank" rel="noopener"><?php echo bg_icon( 'wa', 20 ); ?> Confirm Piercing via WhatsApp</a>
			<p class="bg-small bg-center">Opens a chat with <?php echo esc_html( BG_PHONE ); ?></p>
			<button type="button" class="bg-linkbtn" data-bg-edit>Edit booking</button>
		</div>
	</div>
</div>
	<?php
	return ob_get_clean();
} );

/* Content sections ------------------------------------------------------------------------------------------------ */

add_shortcode( 'bg_reviews', function () {
	$out = '';
	foreach ( BG_REVIEWS as [ $quote, $name, $role ] ) {
		$out .= sprintf( '<li><p class="bg-stars" aria-label="5 out of 5">★★★★★</p><blockquote>&ldquo;%1$s&rdquo;</blockquote><p class="bg-reviews__name">%2$s</p><p class="bg-reviews__role">%3$s</p></li>', esc_html( $quote ), esc_html( $name ), esc_html( $role ) );
	}
	$note = BG_PREVIEW ? '<p class="bg-note">Sample reviews for the preview. Real quotes from the Instagram Reviews highlight go here.</p>' : '';
	return '<ul class="bg-reviews">' . $out . '</ul>' . $note;
} );

add_shortcode( 'bg_faq', function () {
	$out = '';
	foreach ( bg_faq() as $i => [ $q, $a ] ) {
		$out .= sprintf( '<details%1$s><summary>%2$s<span aria-hidden="true">+</span></summary><p>%3$s</p></details>', $i ? '' : ' open', esc_html( $q ), esc_html( $a ) );
	}
	return '<div class="bg-faq">' . $out . '</div>';
} );

add_shortcode( 'bg_ig', function () {
	$out = '';
	foreach ( BG_IG_POSTS as [ $img, $href, $alt ] ) {
		$out .= sprintf( '<li><a href="%1$s" target="_blank" rel="noopener"><img src="%2$s" alt="%3$s" loading="lazy" width="640" height="640"><span>%4$s</span></a></li>', esc_url( $href ), esc_url( bg_asset( 'ig/' . $img ) ), esc_attr( $alt ), bg_icon( 'ig', 24 ) );
	}
	return '<ul class="bg-ig">' . $out . '</ul>';
} );

add_shortcode( 'bg_visit', function () {
	$map = 'https://maps.google.com/maps?q=' . rawurlencode( 'Westlands Commercial Centre, Nairobi, Kenya' ) . '&z=16&output=embed';
	ob_start();
	?>
<div class="bg-visit">
	<div>
		<span class="bg-rule bg-rule--left" aria-hidden="true"></span>
		<p class="bg-label">Visit the studio</p>
		<h2>Westlands Commercial Center</h2>
		<p class="bg-visit__addr"><?php echo bg_icon( 'pin', 18 ); ?> <?php echo esc_html( BG_ADDRESS ); ?>, Kenya</p>
		<div class="bg-hours">
			<p class="bg-hours__head"><span><?php echo bg_icon( 'clock', 16 ); ?> Opening hours</span><b data-bg-open hidden></b></p>
			<dl>
				<div><dt>Monday – Friday</dt><dd>9:00 AM – 6:00 PM</dd></div>
				<div><dt>Saturday</dt><dd>10:00 AM – 5:00 PM</dd></div>
				<div><dt>Sunday</dt><dd>Closed</dd></div>
			</dl>
			<p class="bg-small">Piercings are by appointment. Walk in any time to shop.</p>
		</div>
		<div class="bg-visit__ctas">
			<a class="bg-btn-wa" href="<?php echo esc_url( bg_wa( 'Hi Beauty Galore! ' ) ); ?>" target="_blank" rel="noopener"><?php echo bg_icon( 'wa', 16 ); ?> WhatsApp us</a>
			<a class="bg-btn-outline" href="tel:<?php echo BG_TEL; ?>"><?php echo bg_icon( 'phone', 16 ); ?> Call <?php echo esc_html( BG_PHONE ); ?></a>
		</div>
	</div>
	<div class="bg-map"><iframe title="Map to Westlands Commercial Center, Nairobi" src="<?php echo esc_url( $map ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
</div>
	<?php
	return ob_get_clean();
} );

add_shortcode( 'bg_footer', function () {
	$pay = '';
	foreach ( [ 'M-Pesa', 'Visa / Mastercard', 'Cash' ] as $p ) $pay .= '<li>' . esc_html( $p ) . '</li>';
	return '<div class="bg-foot"><div class="bg-foot__brand">' . bg_logo( true ) . '<p>The best jewellery to suit your style · Curated elegance &amp; precision piercings. Fine &amp; stainless jewellery, ear piercings, accessories and curated gifts.</p></div>'
		. '<nav aria-label="Shop and book"><h3>Shop &amp; book</h3><a href="/#shop">Shop jewellery</a><a href="/?cat=rings#shop" data-bg-goto-cat="rings">Stainless rings</a><a href="/?cat=gifts#shop" data-bg-goto-cat="gifts">Gift sets</a><a href="/#book">Book a piercing</a><a href="/#aftercare">Aftercare guide</a><a href="/#faq">FAQ &amp; policies</a></nav>'
		. '<div><h3>Contact</h3><p><a href="tel:' . BG_TEL . '">Call ' . BG_PHONE . '</a></p><p><a href="' . esc_url( bg_wa( 'Hi Beauty Galore! ' ) ) . '" target="_blank" rel="noopener">WhatsApp ' . BG_PHONE . '</a></p><p><a href="' . esc_url( BG_IG ) . '" target="_blank" rel="noopener">' . BG_IG_HANDLE . '</a></p><p class="bg-dim">' . BG_ADDRESS . '<br>Mon–Fri 9am–6pm · Sat 10am–5pm</p></div>'
		. '<div><h3>We accept</h3><ul class="bg-pay">' . $pay . '</ul></div></div>'
		. '<p class="bg-copy">© ' . gmdate( 'Y' ) . ' Beauty Galore Kenya. All rights reserved.' . ( BG_PREVIEW ? '<span>Preview build: piercing prices are Beauty Galore&rsquo;s; jewellery prices, delivery fees, policies and reviews are samples.</span>' : '' ) . '</p>'
		. '<p class="bg-credit">Developed by <a href="mailto:salvatorewanjohi@gmail.com">Wahome</a></p>';
} );

add_shortcode( 'bg_followers', fn() => BG_FOLLOWERS );
add_shortcode( 'bg_icon', fn( $a ) => bg_icon( $a['name'] ?? 'gem', (int) ( $a['size'] ?? 20 ) ) );

/* Bag drawer, toasts and the floating WhatsApp button: one copy per page, driven by bg.js ------------------------ */
add_action( 'wp_footer', function () {
	$opts = '';
	foreach ( BG_DELIVERY as $k => $d ) {
		$opts .= sprintf(
			'<label class="bg-deliv"><input type="radio" name="bg-deliv" value="%1$s"%2$s><span><b>%3$s</b><small>%4$s</small></span><em>%5$s</em></label>',
			esc_attr( $k ),
			$k === 'rider' ? ' checked' : '',
			esc_html( $d['label'] ),
			esc_html( $d['detail'] ),
			$d['fee'] ? bg_ksh( $d['fee'] ) : 'Free'
		);
	}
	?>
<div class="bg-drawer" data-bg-drawer hidden>
	<button type="button" class="bg-shade" data-bg-close aria-label="Close bag"></button>
	<aside class="bg-drawer__panel" role="dialog" aria-modal="true" aria-label="Shopping bag">
		<header class="bg-drawer__head"><h2>Your bag</h2><button type="button" class="bg-x" data-bg-close aria-label="Close bag">×</button></header>
		<div class="bg-drawer__empty" data-bg-empty>
			<span class="bg-round"><?php echo bg_icon( 'bag', 28 ); ?></span>
			<p class="bg-drawer__empty-title">Your bag is empty</p>
			<p class="bg-muted">Find a piece that suits your style.</p>
			<a class="bg-btn-gold" href="#shop" data-bg-close>Shop the Collection</a>
		</div>
		<div class="bg-drawer__full" data-bg-full hidden>
			<ul class="bg-lines" data-bg-lines></ul>
			<div class="bg-drawer__foot">
				<p class="bg-label">Delivery</p>
				<div class="bg-delivs"><?php echo $opts; ?></div>
				<input class="bg-input" data-bg-area placeholder="Delivery area, e.g. Kilimani, Yaya Centre" aria-label="Delivery location">
				<div class="bg-drawer__pay">
					<dl class="bg-sum"><div><dt>Subtotal</dt><dd data-bg-subtotal></dd></div><div><dt data-bg-deliv-label></dt><dd data-bg-deliv-fee></dd></div><div class="bg-sum__total"><dt>Total</dt><dd data-bg-grand></dd></div></dl>
					<a class="bg-btn-wa bg-btn-block" data-bg-checkout href="#" target="_blank" rel="noopener"><?php echo bg_icon( 'wa', 20 ); ?> Checkout on WhatsApp</a>
					<p class="bg-drawer__small"><span>Pay by M-Pesa, card or cash once confirmed</span><button type="button" data-bg-clear>Clear bag</button></p>
				</div>
			</div>
		</div>
	</aside>
</div>
<div class="bg-toasts" data-bg-toasts aria-live="polite"></div>
<a class="bg-float-wa" href="<?php echo esc_url( bg_wa( 'Hi Beauty Galore! ' ) ); ?>" target="_blank" rel="noopener" aria-label="Chat with Beauty Galore on WhatsApp"><?php echo bg_icon( 'wa', 28 ); ?></a>
	<?php
	$offers = [];
	foreach ( bg_all_products()['shop'] as $p ) {
		$offers[] = [ '@type' => 'Product', 'name' => $p['name'], 'description' => $p['desc'], 'image' => $p['img'] ?: null, 'offers' => [ '@type' => 'Offer', 'price' => $p['price'], 'priceCurrency' => 'KES', 'availability' => 'https://schema.org/InStock' ] ];
	}
	$store = [
		'@type'                     => 'JewelryStore',
		'name'                      => 'Beauty Galore Kenya',
		'telephone'                 => BG_TEL,
		'address'                   => [ '@type' => 'PostalAddress', 'streetAddress' => 'Westlands Commercial Center', 'addressLocality' => 'Nairobi', 'addressCountry' => 'KE' ],
		'openingHours'              => [ 'Mo-Fr 09:00-18:00', 'Sa 10:00-17:00' ],
		'sameAs'                    => [ BG_IG ],
		'url'                       => home_url( '/' ),
	];
	echo '<script type="application/ld+json">' . wp_json_encode( [ '@context' => 'https://schema.org', '@graph' => array_merge( [ $store ], BG_PREVIEW ? [] : $offers ) ] ) . '</script>';
} );

/* Product editor: card fields under Product data → General -------------------------------------------------------- */
add_action( 'woocommerce_product_options_general_product_data', function () {
	echo '<div class="options_group"><p class="form-field"><strong>Beauty Galore card</strong></p>';
	woocommerce_wp_text_input( [ 'id' => '_bg_badge', 'label' => 'Badge', 'description' => 'Short tag on the photo, e.g. Bestseller. Leave empty for none.', 'desc_tip' => true ] );
	woocommerce_wp_select( [ 'id' => '_bg_art', 'label' => 'Drawing (no photo)', 'options' => array_combine( $a = [ 'ring', 'band', 'signet', 'hoop', 'cuff', 'stud', 'chain', 'bracelet', 'labret', 'septum', 'gift' ], array_map( 'ucfirst', $a ) ), 'description' => 'Shown until the product has a photo.', 'desc_tip' => true ] );
	woocommerce_wp_select( [ 'id' => '_bg_tone', 'label' => 'Metal tone', 'options' => [ 'gold' => 'Gold', 'silver' => 'Silver', 'rose' => 'Rose' ] ] );
	woocommerce_wp_checkbox( [ 'id' => '_bg_sample', 'label' => 'Sample price', 'description' => 'Price not yet confirmed by the studio.' ] );
	echo '<p class="form-field"><strong>Piercing service (category "Piercing Services" only)</strong></p>';
	woocommerce_wp_text_input( [ 'id' => '_bg_group', 'label' => 'Booking group', 'description' => 'Ear & cartilage, Facial, Torso or Other.', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_bg_heal', 'label' => 'Healing time', 'description' => 'e.g. 6–12 months. Leave empty for services.', 'desc_tip' => true ] );
	woocommerce_wp_checkbox( [ 'id' => '_bg_adult', 'label' => '18+ only' ] );
	echo '</div>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_bg_badge', '_bg_art', '_bg_tone', '_bg_group', '_bg_heal' ] as $key ) {
		if ( isset( $_POST[ $key ] ) ) $product->update_meta_data( $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
	}
	$product->update_meta_data( '_bg_sample', isset( $_POST['_bg_sample'] ) ? 'yes' : 'no' );
	$product->update_meta_data( '_bg_adult', isset( $_POST['_bg_adult'] ) ? 'yes' : 'no' );
} );

// Pitch build: out of search results until Beauty Galore signs off on prices, photos and copy.
if ( BG_PREVIEW ) add_filter( 'wp_robots', fn( $r ) => array_merge( $r, [ 'noindex' => true, 'nofollow' => true ] ) );

// WooCommerce hooks a mini-cart and an account link into the header navigation; the theme has its own bag.
add_filter( 'hooked_block_types', fn( $types ) => array_values( array_diff( $types, [ 'woocommerce/mini-cart', 'woocommerce/customer-account' ] ) ), 20 );

// The shortcode block runs wpautop, which wraps markup in <p>. All shortcode blocks here return finished markup.
add_filter( 'pre_render_block', function ( $pre, $block ) {
	if ( ( $block['blockName'] ?? '' ) === 'core/shortcode' ) {
		return do_shortcode( trim( $block['innerHTML'] ) );
	}
	return $pre;
}, 10, 2 );
