/*
 * Beauty Galore Kenya: shop filters, the bag (localStorage) with WhatsApp checkout, the piercing booking wizard,
 * aftercare tabs, toasts and the open-now badge. Data comes from window.BG, printed by functions.php from the
 * WooCommerce products, so the static Vercel copy behaves exactly like WordPress.
 */
( function () {
	const BG = window.BG || { products: {}, piercings: [], delivery: {}, hours: {} };
	const $ = ( s, r = document ) => r.querySelector( s );
	const $$ = ( s, r = document ) => [ ...r.querySelectorAll( s ) ];
	const ksh = ( n ) => 'KSh ' + Number( n ).toLocaleString( 'en-KE' );
	const wa = ( text ) => `https://wa.me/${ BG.wa }?text=${ encodeURIComponent( text ) }`;
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	const CHECK = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="m5 12 5 5 9-10"/></svg>';

	/* Toasts ------------------------------------------------------------------------------------------------------ */
	const toasts = $( '[data-bg-toasts]' );
	function toast( title, body ) {
		if ( ! toasts ) return;
		const el = document.createElement( 'div' );
		el.className = 'bg-toast';
		el.innerHTML = `<span class="bg-toast__icon">${ CHECK }</span><p><b>${ esc( title ) }</b>${ body ? `<span>${ esc( body ) }</span>` : '' }</p>`;
		toasts.append( el );
		while ( toasts.children.length > 3 ) toasts.firstChild.remove();
		setTimeout( () => el.classList.add( 'is-out' ), 3400 );
		setTimeout( () => el.remove(), 3700 );
	}

	/* Nairobi time and studio hours ------------------------------------------------------------------------------- */
	const nairobi = () => new Date( Date.now() + 3 * 3600 * 1000 ); // read with getUTC*
	const isoOf = ( d ) => d.toISOString().slice( 0, 10 );
	const SLOT = 30;
	function slotsFor( iso ) {
		const [ y, m, d ] = iso.split( '-' ).map( Number );
		const h = BG.hours[ new Date( Date.UTC( y, m - 1, d ) ).getUTCDay() ];
		if ( ! h ) return [];
		const now = nairobi();
		// An hour's notice for same-day bookings.
		const earliest = isoOf( now ) === iso ? now.getUTCHours() * 60 + now.getUTCMinutes() + 60 : 0;
		const out = [];
		for ( let t = h[ 0 ] * 60; t + SLOT <= h[ 1 ] * 60; t += SLOT ) {
			if ( t >= earliest ) out.push( `${ String( Math.floor( t / 60 ) ).padStart( 2, '0' ) }:${ String( t % 60 ).padStart( 2, '0' ) }` );
		}
		return out;
	}
	const fmtTime = ( hm ) => {
		const [ h, m ] = hm.split( ':' ).map( Number );
		return `${ h % 12 || 12 }:${ String( m ).padStart( 2, '0' ) } ${ h >= 12 ? 'PM' : 'AM' }`;
	};
	const fmtDate = ( iso ) => {
		const [ y, m, d ] = iso.split( '-' ).map( Number );
		return new Date( Date.UTC( y, m - 1, d ) ).toLocaleDateString( 'en-GB', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'UTC' } );
	};

	const openBadge = $( '[data-bg-open]' );
	function tickOpen() {
		if ( ! openBadge ) return;
		const now = nairobi();
		const h = BG.hours[ now.getUTCDay() ];
		const mins = now.getUTCHours() * 60 + now.getUTCMinutes();
		const open = !! h && mins >= h[ 0 ] * 60 && mins < h[ 1 ] * 60;
		openBadge.hidden = false;
		openBadge.textContent = open ? 'Open now' : 'Closed now';
		openBadge.className = open ? 'is-open' : 'is-closed';
	}
	tickOpen();
	setInterval( tickOpen, 60000 );

	// Home: the header sits white over the cover, then drops in solid once the page scrolls (as on Aura Glow).
	if ( document.body.classList.contains( 'home' ) ) {
		const paint = () => document.body.classList.toggle( 'bg-scrolled', window.scrollY > 140 );
		paint();
		addEventListener( 'scroll', paint, { passive: true } );
	}

	// Scroll to an element below the fixed header. (scrollIntoView can also scroll clipped containers sideways.)
	const goTo = ( el ) => {
		if ( ! el ) return;
		const head = document.querySelector( ".bg-header" )?.offsetHeight || 0;
		const bar = document.body.classList.contains( "admin-bar" ) ? 32 : 0;
		window.scrollTo( { top: el.getBoundingClientRect().top + window.scrollY - head - bar - 12, behavior: "smooth" } );
	};

	/* Shop filters ------------------------------------------------------------------------------------------------ */
	const shop = $( '[data-bg-shop]' );
	function filter( cat, scroll ) {
		if ( ! shop ) return;
		if ( cat !== 'all' && ! $( `[data-bg-cat="${ cat }"]`, shop ) ) cat = 'all';
		$$( '[data-bg-cat]', shop ).forEach( ( b ) => {
			const on = b.dataset.bgCat === cat;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on );
		} );
		$$( '[data-bg-cat-note]', shop ).forEach( ( p ) => ( p.hidden = p.dataset.bgCatNote !== cat ) );
		$$( '.bg-card', shop ).forEach( ( c ) => {
			const show = cat === 'all' || c.dataset.cat === cat;
			c.hidden = ! show;
			c.classList.remove( 'is-in' );
			if ( show ) requestAnimationFrame( () => c.classList.add( 'is-in' ) );
		} );
		// "All" is capped at 8 pieces on phones (CSS) until the visitor asks for the rest.
		const cards = $( ".bg-cards", shop );
		const more = $( "[data-bg-more]", shop );
		const capped = cat === "all" && ! shop.dataset.expanded;
		cards?.classList.toggle( "is-capped", capped );
		if ( more ) more.hidden = ! capped;
		if ( scroll ) goTo( $( "#shop" ) );
	}
	shop?.addEventListener( 'click', ( e ) => {
		if ( e.target.closest( "[data-bg-more]" ) ) {
			shop.dataset.expanded = "1";
			return filter( "all", false );
		}
		const b = e.target.closest( '[data-bg-cat]' );
		if ( b ) filter( b.dataset.bgCat, false );
	} );
	// Menu links like /?cat=rings#shop filter in place instead of reloading.
	document.addEventListener( 'click', ( e ) => {
		const a = e.target.closest( 'a[href*="cat="]' );
		if ( ! a || ! shop ) return;
		const url = new URL( a.href, location.href );
		if ( url.pathname !== location.pathname ) return;
		e.preventDefault();
		history.replaceState( null, '', url.search + '#shop' );
		filter( url.searchParams.get( 'cat' ) || 'all', true );
		document.querySelector( '.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation__responsive-container-close' )?.click();
	} );
	const startCat = new URLSearchParams( location.search ).get( 'cat' );
	if ( startCat ) filter( startCat, false );

	/* Bag ---------------------------------------------------------------------------------------------------------- */
	const KEY = 'bg-bag-v1';
	let bag = {};
	try {
		bag = JSON.parse( localStorage.getItem( KEY ) || '{}' ) || {};
	} catch {}
	for ( const id of Object.keys( bag ) ) if ( ! BG.products[ id ] ) delete bag[ id ];
	const save = () => {
		try {
			localStorage.setItem( KEY, JSON.stringify( bag ) );
		} catch {}
	};
	const drawer = $( '[data-bg-drawer]' );
	// The floating WhatsApp button steps aside while the bag is open or the booking card is on screen,
	// so it never covers Continue or Checkout.
	const floatWa = $( ".bg-float-wa" );
	let bookingInView = false;
	const bookingCard = $( "[data-bg-booking]" );
	if ( floatWa && bookingCard && "IntersectionObserver" in window ) {
		new IntersectionObserver( ( [ entry ] ) => {
			bookingInView = entry.isIntersecting;
			floatWa.classList.toggle( "is-away", bookingInView || ( drawer && ! drawer.hidden ) );
		} ).observe( bookingCard );
	}
	const countEl = $( '[data-bg-count]' );
	const area = $( '[data-bg-area]' );

	function renderBag() {
		const ids = Object.keys( bag );
		const count = ids.reduce( ( n, id ) => n + bag[ id ], 0 );
		if ( countEl ) {
			countEl.hidden = ! count;
			countEl.textContent = count;
		}
		const bagBtn = $( '[data-bg-open-bag]' );
		bagBtn?.setAttribute( 'aria-label', `Open shopping bag, ${ count } item${ count === 1 ? '' : 's' }` );
		if ( ! drawer ) return;
		$( '[data-bg-empty]', drawer ).hidden = !! ids.length;
		$( '[data-bg-full]', drawer ).hidden = ! ids.length;
		if ( ! ids.length ) return;
		$( '[data-bg-lines]', drawer ).innerHTML = ids
			.map( ( id ) => {
				const p = BG.products[ id ];
				const img = p.img ? `<img src="${ esc( p.img ) }" alt="">` : p.art;
				return `<li class="bg-line"><div class="bg-line__img">${ img }</div><div class="bg-line__body"><b>${ esc( p.name ) }</b><small>${ ksh( p.price ) } each</small>
					<div class="bg-line__row"><div class="bg-qty"><button type="button" data-bg-qty="${ id }" data-d="-1" aria-label="Decrease quantity">−</button><span>${ bag[ id ] }</span><button type="button" data-bg-qty="${ id }" data-d="1" aria-label="Increase quantity">+</button></div>${ ksh( p.price * bag[ id ] ) }</div></div>
					<button type="button" class="bg-line__rm" data-bg-rm="${ id }" aria-label="Remove ${ esc( p.name ) }">×</button></li>`;
			} )
			.join( '' );
		const subtotal = ids.reduce( ( n, id ) => n + BG.products[ id ].price * bag[ id ], 0 );
		const dk = $( 'input[name="bg-deliv"]:checked', drawer )?.value || 'rider';
		const d = BG.delivery[ dk ];
		area.hidden = dk === 'pickup';
		area.placeholder = dk === 'courier' ? 'Town and courier office' : 'Delivery area, e.g. Kilimani, Yaya Centre';
		$( '[data-bg-subtotal]', drawer ).textContent = ksh( subtotal );
		$( '[data-bg-deliv-label]', drawer ).textContent = d.label;
		$( '[data-bg-deliv-fee]', drawer ).textContent = d.fee ? ksh( d.fee ) : 'Free';
		$( '[data-bg-grand]', drawer ).textContent = ksh( subtotal + d.fee );
		const lines = ids.map( ( id, i ) => `${ i + 1 }. ${ BG.products[ id ].name } × ${ bag[ id ] } = ${ ksh( BG.products[ id ].price * bag[ id ] ) }` );
		const msg = [
			"Hi Beauty Galore! I'd like to place this order:",
			'',
			...lines,
			'',
			`Subtotal: ${ ksh( subtotal ) }`,
			`${ d.label }: ${ d.fee ? ksh( d.fee ) : 'Free' }`,
			`*Total: ${ ksh( subtotal + d.fee ) }*`,
			dk === 'pickup' ? `I'll collect at ${ BG.address }.` : `Deliver to: ${ area.value.trim() || "(I'll share my location)" }`,
			'',
			'Please confirm availability and payment details. Thank you!',
		].join( '\n' );
		$( '[data-bg-checkout]', drawer ).href = wa( msg );
	}

	function openBag( open ) {
		if ( ! drawer ) return;
		drawer.hidden = ! open;
		floatWa?.classList.toggle( 'is-away', open || bookingInView );
		document.documentElement.style.overflow = open ? 'hidden' : '';
		if ( open ) $( '.bg-x', drawer )?.focus();
	}
	function add( id ) {
		if ( ! BG.products[ id ] ) return;
		bag[ id ] = ( bag[ id ] || 0 ) + 1;
		save();
		renderBag();
		toast( 'Added to your bag', BG.products[ id ].name );
		if ( countEl ) {
			countEl.classList.remove( 'is-pop' );
			void countEl.offsetWidth;
			countEl.classList.add( 'is-pop' );
		}
	}

	document.addEventListener( 'click', ( e ) => {
		const t = e.target;
		const addBtn = t.closest( '[data-bg-add]' );
		if ( addBtn ) return add( addBtn.dataset.bgAdd );
		if ( t.closest( '[data-bg-open-bag]' ) ) return openBag( true );
		if ( t.closest( '[data-bg-close]' ) ) return openBag( false );
		const q = t.closest( '[data-bg-qty]' );
		if ( q ) {
			const id = q.dataset.bgQty;
			bag[ id ] = ( bag[ id ] || 0 ) + Number( q.dataset.d );
			if ( bag[ id ] <= 0 ) delete bag[ id ];
			save();
			return renderBag();
		}
		const rm = t.closest( '[data-bg-rm]' );
		if ( rm ) {
			delete bag[ rm.dataset.bgRm ];
			save();
			return renderBag();
		}
		if ( t.closest( '[data-bg-clear]' ) ) {
			bag = {};
			save();
			return renderBag();
		}
		if ( t.closest( '[data-bg-checkout]' ) ) toast( 'Opening WhatsApp', 'Your itemised order is ready to send' );
	} );
	drawer?.addEventListener( 'change', renderBag );
	area?.addEventListener( 'input', renderBag );
	document.addEventListener( 'keydown', ( e ) => e.key === 'Escape' && drawer && ! drawer.hidden && openBag( false ) );
	renderBag();

	/* Aftercare tabs ------------------------------------------------------------------------------------------------ */
	$$( '[data-bg-care]' ).forEach( ( b ) =>
		b.addEventListener( 'click', () => {
			$$( '[data-bg-care]' ).forEach( ( x ) => {
				x.classList.toggle( 'is-on', x === b );
				x.setAttribute( 'aria-pressed', x === b );
			} );
			$$( '[data-bg-care-panel]' ).forEach( ( p ) => ( p.hidden = p.dataset.bgCarePanel !== b.dataset.bgCare ) );
		} )
	);

	/* Piercing booking ------------------------------------------------------------------------------------------- */
	const book = $( '[data-bg-booking]' );
	if ( ! book ) return;
	const byId = Object.fromEntries( BG.piercings.map( ( p ) => [ p.id, p ] ) );
	const state = { step: 0, picked: [], date: '', time: '', ref: 'BG-' + Math.random().toString( 36 ).slice( 2, 6 ).toUpperCase() };
	const steps = $$( '[data-bg-step]', book );
	const next = $( '[data-bg-next]', book );
	const back = $( '[data-bg-back]', book );
	const nameIn = $( '[data-bg-name]', book );
	const phoneIn = $( '[data-bg-phone]', book );
	const notesIn = $( '[data-bg-notes]', book );

	const chosen = () => state.picked.map( ( id ) => byId[ id ] ).filter( Boolean );
	const phoneOk = () => /^(?:\+?254|0)?[17]\d{8}$/.test( phoneIn.value.replace( /[\s-]/g, '' ) );
	const age = () => $( 'input[name="bg-age"]:checked', book )?.value || '';
	const adultOnly = () => chosen().some( ( p ) => p.adult );
	const jewel = () => $( 'input[name="bg-jewel"]:checked', book )?.value || 'Stainless steel starter';
	const valid = () =>
		[
			() => chosen().length > 0,
			() => true,
			() => !! state.date && slotsFor( state.date ).includes( state.time ),
			() => nameIn.value.trim().length > 1 && phoneOk() && ( age() === 'adult' || ( age() === 'minor' && ! adultOnly() ) ),
		][ state.step ]();

	function update() {
		steps.forEach( ( s, i ) => ( s.hidden = i !== state.step ) );
		$$( '.bg-steps li', book ).forEach( ( li, i ) => {
			li.classList.toggle( 'is-on', i === state.step );
			li.classList.toggle( 'is-done', i < state.step );
			if ( i === state.step ) li.setAttribute( 'aria-current', 'step' );
			else li.removeAttribute( 'aria-current' );
		} );
		back.hidden = state.step === 0;
		next.innerHTML = state.step < 3 ? 'Continue →' : 'Review booking →';
		next.disabled = ! valid();
		const c = chosen();
		$( '[data-bg-total]', book ).textContent = ksh( c.reduce( ( n, p ) => n + p.price, 0 ) );
		$( '[data-bg-chosen]', book ).textContent = c.map( ( p ) => p.name ).join( ', ' );
		$( '[data-bg-phone-hint]', book ).hidden = ! phoneIn.value || phoneOk();
		$( '[data-bg-age-hint]', book ).hidden = ! ( age() === 'minor' && adultOnly() );
	}

	// Step 1: placements.
	book.addEventListener( 'click', ( e ) => {
		const g = e.target.closest( '[data-bg-group]' );
		if ( g ) {
			$$( '[data-bg-group]', book ).forEach( ( b ) => {
				b.classList.toggle( 'is-on', b === g );
				b.setAttribute( 'aria-pressed', b === g );
			} );
			$$( '[data-bg-group-list]', book ).forEach( ( l ) => ( l.hidden = l.dataset.bgGroupList !== g.dataset.bgGroup ) );
			return;
		}
		const p = e.target.closest( '[data-bg-pierce]' );
		if ( p ) {
			const id = p.dataset.bgPierce;
			state.picked = state.picked.includes( id ) ? state.picked.filter( ( x ) => x !== id ) : [ ...state.picked, id ];
			p.setAttribute( 'aria-pressed', state.picked.includes( id ) );
			return update();
		}
		const day = e.target.closest( '[data-bg-day]' );
		if ( day ) {
			state.date = day.dataset.bgDay;
			state.time = '';
			renderDays();
			return update();
		}
		const slot = e.target.closest( '[data-bg-slot]' );
		if ( slot ) {
			state.time = slot.dataset.bgSlot;
			$$( '[data-bg-slot]', book ).forEach( ( s ) => s.classList.toggle( 'is-on', s === slot ) );
			return update();
		}
	} );
	book.addEventListener( 'input', update );
	book.addEventListener( 'change', update );

	// Step 3: the next three weeks, Sundays and full days closed.
	function renderDays() {
		const now = nairobi();
		const days = [];
		for ( let i = 0; i < 21; i++ ) {
			const d = new Date( Date.UTC( now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + i ) );
			const iso = isoOf( d );
			days.push( { iso, i, sun: d.getUTCDay() === 0, closed: ! slotsFor( iso ).length, d } );
		}
		if ( ! state.date || ! slotsFor( state.date ).length ) state.date = days.find( ( x ) => ! x.closed )?.iso || '';
		$( '[data-bg-days]', book ).innerHTML = days
			.map( ( x ) => {
				const label = x.i === 0 ? 'Today' : x.i === 1 ? 'Tmrw' : x.d.toLocaleDateString( 'en-GB', { weekday: 'short', timeZone: 'UTC' } );
				const foot = x.closed ? ( x.sun ? 'Closed' : 'Full' ) : x.d.toLocaleDateString( 'en-GB', { month: 'short', timeZone: 'UTC' } );
				return `<button type="button" class="bg-day${ x.iso === state.date ? ' is-on' : '' }" data-bg-day="${ x.iso }"${ x.closed ? ' disabled' : '' } aria-pressed="${ x.iso === state.date }"><small>${ label }</small><b>${ x.d.getUTCDate() }</b><small>${ foot }</small></button>`;
			} )
			.join( '' );
		$( '[data-bg-day-label]', book ).textContent = state.date ? fmtDate( state.date ) : '';
		$( '[data-bg-slots]', book ).innerHTML = ( state.date ? slotsFor( state.date ) : [] )
			.map( ( s ) => `<button type="button" class="bg-slot${ s === state.time ? ' is-on' : '' }" data-bg-slot="${ s }">${ fmtTime( s ) }</button>` )
			.join( '' );
	}

	next.addEventListener( 'click', () => {
		if ( ! valid() ) return;
		if ( state.step === 2 && ! slotsFor( state.date ).includes( state.time ) ) {
			toast( 'Pick another time', 'That slot is outside studio hours or has passed.' );
			renderDays();
			return update();
		}
		if ( state.step < 3 ) {
			state.step++;
			if ( state.step === 2 ) renderDays();
			update();
			goTo( book );
			return;
		}
		showSummary();
	} );
	back.addEventListener( 'click', () => {
		state.step = Math.max( 0, state.step - 1 );
		update();
	} );
	$( '[data-bg-edit]', book ).addEventListener( 'click', () => {
		$( '[data-bg-summary]', book ).hidden = true;
		$( '[data-bg-wizard]', book ).hidden = false;
	} );

	function showSummary() {
		const c = chosen();
		const total = c.reduce( ( n, p ) => n + p.price, 0 );
		const ti = jewel().includes( 'titanium' );
		const totalText = ksh( total ) + ( ti ? ' + titanium upgrade' : '' );
		const name = nameIn.value.trim();
		const when = `${ fmtDate( state.date ) } · ${ fmtTime( state.time ) }`;
		const rows = [ [ 'Reference', state.ref ], ...c.map( ( p ) => [ p.name, ksh( p.price ) ] ), [ 'Jewellery', jewel() ], [ 'When', when ], [ 'Estimated total', totalText, true ] ];
		$( '[data-bg-summary-list]', book ).innerHTML = rows.map( ( [ k, v, gold ] ) => `<div><dt>${ esc( k ) }</dt><dd${ gold ? ' class="is-gold"' : '' }>${ esc( v ) }</dd></div>` ).join( '' );
		$( '[data-bg-hello]', book ).textContent = `Almost there, ${ name.split( ' ' )[ 0 ] }!`;
		const msg = [
			`Hi Beauty Galore! I'd like to book a piercing appointment. (Ref ${ state.ref })`,
			'',
			`Piercing: ${ c.map( ( p ) => `${ p.name } (${ ksh( p.price ) })` ).join( ', ' ) }`,
			`Jewellery: ${ jewel() }`,
			`Date: ${ fmtDate( state.date ) }`,
			`Time: ${ fmtTime( state.time ) }`,
			`Estimated total: ${ totalText }`,
			'',
			`Name: ${ name }`,
			`Phone: ${ phoneIn.value.trim() }`,
			`Age: ${ age() === 'adult' ? '18 or over, bringing my ID' : 'Under 18, coming with a parent/guardian and ID' }`,
			...( notesIn.value.trim() ? [ `Notes: ${ notesIn.value.trim() }` ] : [] ),
			'',
			'Please confirm my slot. Thank you!',
		].join( '\n' );
		$( '[data-bg-confirm]', book ).href = wa( msg );
		$( '[data-bg-wizard]', book ).hidden = true;
		$( '[data-bg-summary]', book ).hidden = false;
		toast( 'Slot request ready', when );
		goTo( book );
	}

	update();
} )();
